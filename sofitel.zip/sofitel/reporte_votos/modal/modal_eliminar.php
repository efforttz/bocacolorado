
<!-- Ventana modal para eliminar -->
<div class="modal fade" id="modal_eliminar<?php echo $rowDataCliente['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header btn btn-success d-flex justify-content-center">
        <h4 class="modal-title">
          ¿Realmente deseas eliminar a ?
        </h4>
      </div>
      <div class="modal-body">
        <strong style="text-align: center !important">
          <?php echo $rowDataCliente['nombre']; ?>
        </strong>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cerrar</button>
        <a href="cod_eliminar.php?eliminar=<?php echo $rowDataCliente['id']; ?>" class="btn btn-danger">Eliminar</a>
      </div>
    </div>
  </div>
</div>
<!---fin ventana eliminar--->
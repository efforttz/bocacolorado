
   <!-- codigo modal registrar -->
   <div class="modal fade" id="modal_registrar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
       <div class="modal-dialog">
           <div class="modal-content">
               <div class="modal-header btn btn-success d-flex justify-content-center">
                   <h4 class="modal-title">¡Registrar Datos!</h4>

               </div>
               <div class="modal-body">
                   <form action="cod_registrar.php" class="" method="POST" enctype="multipart/form-data">


                       <div class="mb-1 row">
                           <label class="col-sm-2 control-label text-md-right"><strong>Dni:</strong></label>
                           <div class="col-sm-10">
                               <input type="number" name="dni" class="form-control" required autofocus>
                           </div>
                       </div>

                       <div class="mb-1 row">
                           <label  class="col-sm-2 control-label text-md-right"><strong>Nombre:</strong></label>
                           <div class="col-sm-10">
                               <input type="text" name="nombre" class="form-control" required>
                           </div>
                       </div>

                       <div class="mb-1 row">
                           <label class="col-sm-2 control-label text-md-right"><strong>Cargo:</strong></label>
                           <div class="col-sm-10">
                               <input type="text" name="cargo" class="form-control" required>
                           </div>
                       </div>

                       <div class="mb-1 row">
                           <label  class="col-sm-2 control-label text-md-right"><strong>Foto:</strong></label>
                           <div class="col-sm-10">
                               <input type="file" name="imagen" class="form-control" required>
                           </div>
                       </div>

                       <div class="modal-footer">
                           <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cerrar</button>
                           <button type="submit" class="btn btn-danger" name="enviar">guardar</button>
                       </div>
                   </form>
               </div>
           </div>
       </div>
   </div>
   <!-- Modal -->
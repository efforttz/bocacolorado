<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    echo '
    <script>
    alert("por fabor debes iniciar sesion");
    window.location = "sistemalogin/index.php";
    </script>
    ';
    session_destroy();
    die();
}

?>
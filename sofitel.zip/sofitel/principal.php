
<!--  nuestro header -->
<?php include("includes/header.php"); ?>

<div class="container">
    <div class="row">
        <div class="navbar navbar-light bg-light">
            <div class="col-md-8">
                <!--  Modal Registrar-->
                <?php include("modal/modal_registrar.php"); ?>
                <!-- buton Modal Registrar-->
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modal_registrar"><i class="fas fa-user-plus "></i> Nuevo Usuario</button>
                
                <a href="cod_reportes.php" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                <i class="fas fa-download fa-sm"></i> Reportes Pdf</a>
            </div>
            <div class="col-md-4">
                <!-- formulario buscador-->
                <form action="buscador.php" method="GET" class="d-flex">
                    <input class="form-control me-2" type="text" name="buscar" placeholder="buscar">
                    <input class="btn btn-primary" type="submit" name="enviar" value="buscar">
                </form>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover">
                    <thead class="table-success">
                        <tr class="text-center">
                            <th>ID</th>
                            <th>NOMBRE COMPLETO</th>
                            <th>DNI</th>
                            <th>GRADO</th>
                            <th>SECCION</th>
                            <th>CLAVE</th>
                            <th colspan="2">ACCIONES</th>
                        </tr>
                        <tr></tr>
                    </thead>
                    <tbody>
                        <!-- codigo de pintar paginas en filas-->
                        <?php
                        //conectar a base de datos
                        include("cod_conexion.php"); 
                        if (isset($_GET['page'])) {
                            $page = $_GET['page'];
                        } else {
                            $page = 1;
                        }

                        $numero_por_pag = 6;
                        $empezarDesde = ($page - 1) * 6;
                         // pintar dato sofitel con limite de 5 
                        $consultaPaginacion = "SELECT * FROM alumnos limit $empezarDesde, $numero_por_pag";
                        $resultado = mysqli_query($con, $consultaPaginacion);
                        // cliclo while
                        while ($rowDataCliente = mysqli_fetch_assoc($resultado)) { ?>
                            <tr>
                                <td><?php echo $rowDataCliente['id']; ?></td>
                                <td><?php echo $rowDataCliente['nombre']; ?></td>
                                <td><?php echo $rowDataCliente['dni']; ?></td>
                                <td><?php echo $rowDataCliente['grado']; ?></td>
                                <td><?php echo $rowDataCliente['seccion']; ?></td>
                                <td><?php echo $rowDataCliente['clave']; ?></td>
                         
                                <td>
                                    <button type="button" class="btn btn-warning"data-bs-toggle="modal" data-bs-target="#modal_editar<?php echo $rowDataCliente['id']; ?>">
                                    Editar
                                    </button>                          
                                    <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modal_eliminar<?php echo $rowDataCliente['id']; ?>">
                                    Eliminar
                                    </button>
                                </td>
                            </tr>
                            <!--  Modal eliminar-->
                            <?php include("modal/modal_eliminar.php"); ?>
                            <!--  Modal editar-->
                            <?php include("modal/modal_editar.php"); ?>


                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!--  codigo paginacion-->
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <?php include("cod_numerador.php"); ?>
        </div>
        <div class="col-md-6 pagination justify-content-end">
            <?php include("cod_paginacion.php"); ?>
        </div>
    </div>
</div>

<!--  nuestro footer-->
<?php include("includes/footer.php"); ?>

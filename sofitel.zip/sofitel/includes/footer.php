
            </div>
            <!-- fin de contenido -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Sofitel-Perú Nº 964900700</span>
                    </div>
                </div>
            </footer>
            <!-- fin de  Footer -->
        </div>
        <!-- End of Content Wrapper -->
    </div>
    <!-- End of Page Wrapper -->

 
    <!-- codigo vendor de plantilla-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- codigo js de plantilla-->
<script src="js/sb-admin-2.min.js"></script>

<!-- codigo js de awesome-->
<script src="js/a265c79f71.js" crossorigin="anonymous"></script>

<!-- codigo js de boostrap 5-->
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>

 <!-- codigo js de https://datatables.net/-->
<script src="js/jquery-3.5.1.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function() {
        $('#alumnos').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.11.3/i18n/es_es.json'
            }
        });
    });
</script>

</body>

</html>
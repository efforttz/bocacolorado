<?php
include("cod_conexion.php");
$consultaPag = "SELECT * FROM candidatos";
$resultado = mysqli_query($con,$consultaPag);
$totalrecorido = mysqli_num_rows($resultado);
$totalpaginas = ceil($totalrecorido/$numero_por_pag);
echo $totalpaginas." Páginas mostradas de: ".$totalrecorido." Registrados";
?>
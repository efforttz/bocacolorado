
<!--codigo para editar--->
<?php
include("cod_conexion.php");
   if(isset($_POST['editar'])){
       $idActualizar = $_REQUEST['id'];
       $dni = $_POST['dni'];
       $nombre_candidato = $_POST['nombre_candidato'];
       $partido_politico = $_POST['partido_politico'];
       $imagen = addslashes(file_get_contents($_FILES['imagen']['tmp_name']));
       
       $consultaActualizar = "UPDATE candidatos SET dni='$dni',nombre_candidato='$nombre_candidato',partido_politico='$partido_politico', imagen='$imagen' WHERE id=$idActualizar";
       $resultado = mysqli_query($con, $consultaActualizar);
       header("location: candidatos.php");
   } 
?>









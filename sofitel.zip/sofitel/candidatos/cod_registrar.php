<!-- codigo para registrar -->
<?php
include("cod_conexion.php");
if (isset($_POST['enviar'])) {
    $dni = $_POST['dni'];
    $nombre_candidato = $_POST['nombre_candidato'];
    $partido_politico = $_POST['partido_politico'];
    $imagen = addslashes(file_get_contents($_FILES['imagen']['tmp_name']));
    $consultaRegistro = "INSERT INTO candidatos(dni, nombre_candidato, partido_politico, imagen) VALUES ('$dni', '$nombre_candidato', '$partido_politico','$imagen')";
    $resultado = mysqli_query($con, $consultaRegistro);
    if ($resultado) {
        header("location: candidatos.php");
    } else {
        echo "no se inserto datos";
    }
}
?>

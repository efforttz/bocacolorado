<!--  nuestro header -->
<?php include("includes/header.php"); ?>
<div class="container">
    <div class="row">
        <div class="navbar navbar-light bg-light">
            <div class="col-md-8">
                <!--  Modal Registrar-->
                                
                <?php include("modal/modal_registrar.php"); ?>
                <!-- buton Modal Registrar-->
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modal_registrar">Registrar Usuarios</button>
            </div>
            <div class="col-md-4">
                <!-- formulario buscador-->
                <form action="buscador.php" method="GET" class="d-flex">
                    <input class="form-control me-2" type="text" name="buscar" placeholder="buscar">
                    <input class="btn btn-primary" type="submit" name="enviar" value="buscar">
                </form>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover">
                    <thead class="table-warning">
                        <tr class="text-center">
                            <th>ID</th>
                            <th>DNI</th>
                            <th>NOMBRE</th>
                            <th>CARGO</th>
                            <th>IMAGEN</th>
                            <th>ACCIONES</th>
                        </tr>
                        <tr></tr>
                    </thead>
                    <tbody>
                        <!-- codigo de pintar paginas en filas-->
                        <?php
                        include("cod_conexion.php"); 
                        if (isset($_GET['page'])) {
                            $page = $_GET['page'];
                        } else {
                            $page = 1;
                        }

                        $numero_por_pag = 5;
                        $empezarDesde = ($page - 1) * 5;
                        // codigo buscador
                        if (isset($_GET['enviar'])) {
                            $buscar = $_GET['buscar'];
                            $consultaBuscar = "SELECT * FROM candidatos WHERE dni LIKE '%$buscar%' OR nombre_candidato LIKE '%$buscar%' OR partido_politico LIKE '%$buscar%' limit $empezarDesde, $numero_por_pag";
                            $resultado = mysqli_query($con, $consultaBuscar);
                        }
                        // cliclo while
                        while ($rowDataCliente = mysqli_fetch_assoc($resultado)) { ?>
                            <tr>
                                <td><?php echo $rowDataCliente['id']; ?></td>
                                <td><?php echo $rowDataCliente['dni']; ?></td>
                                <td><?php echo $rowDataCliente['nombre_candidato']; ?></td>
                                <td><?php echo $rowDataCliente['partido_politico']; ?></td>
                                <td class="text-center"><img class="img-thumbnail rounded" src="data:image/jpg;base64,<?php echo base64_encode($rowDataCliente['imagen']); ?>" width="50" height=""></td>
                                <td>
                                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modal_editar<?php echo $rowDataCliente['id']; ?>">
                                        Editar
                                    </button>                        
                                    <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modal_eliminar<?php echo $rowDataCliente['id']; ?>">
                                        Eliminar
                                    </button>
                                </td>

                            </tr>
                            <!--  Modal eliminar-->
                            <?php include("modal/modal_eliminar.php"); ?>
                            <!--  Modal editar-->
                            <?php include("modal/modal_editar.php"); ?>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!--  codigo paginacion-->
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <?php include("cod_numerador.php"); ?>
        </div>
        <div class="col-md-6 pagination justify-content-end">
            <?php include("cod_paginacion.php"); ?>
        </div>
    </div>
</div>
<!--  nuestro footer-->

<!--  nuestro footer-->
<?php include("includes/footer.php"); ?>
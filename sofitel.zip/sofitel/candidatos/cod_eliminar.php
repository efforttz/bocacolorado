
<!-- codigo para eliminar -->
<?php
include("cod_conexion.php");
    if(isset($_GET['eliminar'])){
        $idEliminar = $_GET['eliminar'];
        $consultaEliminar = "DELETE FROM candidatos where id = $idEliminar";
        $resultado = mysqli_query($con,$consultaEliminar);
        if(!$resultado){
            die("consulta fallido");
        }    
        header("location: candidatos.php");
    }
?>


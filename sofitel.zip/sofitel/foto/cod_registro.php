<?php 
include("cod_conexion.php");

if(isset($_POST['enviar'])){
    $nombre = $_POST['nombre'];
    $clave = $_POST['clave'];
    $imagen = $_FILES['imagen']['name'];
    $archivo = $_FILES['imagen']['tmp_name'];
    $ruta = "img";
    $ruta = $ruta."/".$imagen;
    move_uploaded_file($archivo,$ruta);

    $resultado = $con->query("INSERT INTO imagenes(nombre,clave,imagen) VALUES ('$nombre','$clave','$imagen')");

    if(!isset($resultado)){
        echo "el registro fallo";
        die;
    }
     header("location:registro.php");
}


?>
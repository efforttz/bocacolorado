<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<center>
<br><br>
<a href="registro.php">registrar</a>
<table class="table">
    <thead>
    <?php
    include("cod_conexion.php");
    $resultado = $con->query("SELECT*FROM imagenes");  
    ?>
        <tr>
            <th>nombre</th>
            <th>clave</th>
            <th>imagen</th>
            <th>acciones</th>
        </tr>
    </thead>
    <?php 
    while($fila=mysqli_fetch_assoc($resultado)) { ?> 
    <tbody>
        <tr>
            <td><?php echo $fila['nombre']; ?></td>
            <td><?php echo $fila['clave']; ?></td>
            <td><?php echo $fila['imagen']; ?></td>
            <td>
                <a href="editar.php">editar</a>
                <a href="cod_eliminar.php?eliminar=<?php echo $fila['id']; ?>">eliminar</a>
            </td>
        </tr>
    </tbody>
    <?php  } ?>
</table>
</center>
    
</body>
</html>
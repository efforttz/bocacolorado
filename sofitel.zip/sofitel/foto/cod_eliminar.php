<?php 

include("cod_conexion.php");
if(isset($_GET['eliminar'])){
    $eliminar_id= $_GET['eliminar'];
    $consulta_eliminar = "DELETE FROM imagenes WHERE id = $eliminar_id";
    $resultado = mysqli_query($con,$consulta_eliminar);
    if(!$resultado){
        die("consulta fallido");
    }    
    header("location: index.php");
}


?>
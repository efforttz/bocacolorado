<?php 
include("cod_conexion.php");

if(isset($_POST['editar'])){
    $actualizar_id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $clave = $_POST['clave'];
    $imagen = $_FILES['imagen']['name'];
    $archivo = $_FILES['imagen']['tmp_name'];
    $ruta = "img";
    $ruta = $ruta."/".$imagen;
    move_uploaded_file($archivo,$ruta); 
   // $resultado = $con->query("INSERT INTO imagenes(nombre,clave,imagen) VALUES ('$nombre','$clave','$imagen')");
   $editar_datos = "UPDATE imagenes SET nombre='$nombre', clave='$clave', imagen='$imagen' WHERE id=$actualizar_id";
   $resultado = mysqli_query($con, $editar_datos);
   if(!$resultado){
    die("non se edito");
   }
   header("location: index.php");
} 


?>
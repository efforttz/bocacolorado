<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<form action="cod_editar.php" method="POST"  enctype="multipart/form-data">
<?php
    include("cod_conexion.php");
    $resultado = $con->query("SELECT*FROM imagenes");  
    ?>
    nombre <input type="text" name="nombre" value="<?php echo $fila['nombre']; ?>"><br>
    clave <input type="password" name="clave" value="<?php echo $fila['clave']; ?> "><br>
    subir foto <input type="file" name="imagen" value="<?php echo $fila['imagen']; ?>"><br>
    <button type="submit" name="editar">enviar</button>
</form>
    
</body>
</html>
<?php
session_start();
include_once("../cod_conexion.php");

if(isset($_POST['enviar'])){   
    
    $dni = $_POST['dni'];
    $clave = $_POST['clave'];
    

    $seleccionar_datos = "SELECT*FROM alumnos WHERE dni= '$dni'and clave = '$clave'";
    $resultado = mysqli_query($con,$seleccionar_datos);
    
    //$resultado = $con->query("SELECT*FROM datossofitel WHERE correo= '$correo' and clave = '$clave' ");
   
    $filas_login =mysqli_num_rows($resultado);

    if($filas_login >0)
    {
        $_SESSION['dni']= $dni;

        header("location: votos.php");
        exit;
    }
    else
    {
        $_SESSION['mensaje'] = "correo o clave incorrecto";
        $_SESSION['mensaje_type'] = "danger";
        header("location:login.php");
        exit;
    }

}

?>
<?php session_start(); ?> 
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
  <link rel="stylesheet" href="css/style.css">
  <title>Login Form Demo</title>
</head>
<body>
  <div class="contenedor">
    <form class="formulario" action="cod_login.php" method="POST" >
      <img class="formulario_img" src="img/unap.png" alt="">
      <h2 class="formulario_h2" >Iniciar Sesión</h2>
      <?php             
      if (isset($_SESSION['mensaje'])) { ?>
          <div class="alert alert-<?= $_SESSION['mensaje_type']; ?> alert-dismissible fade show" role="alert">
              <?= $_SESSION['mensaje']; ?>
          </div>
      <?php  session_destroy();      
      } ?>
      <div class="input-group">
        <input type="number" name="dni" id="id_correo" placeholder="Nº DNI" required>
       
      </div>
     
      <div class="input-group">
        <input type="password" name="clave" id="id_clave" placeholder="Contraseña" required>
      </div>

      <input class="btn" type="submit" name="enviar"  value="enviar" >
    </form>
  </div>
</body>
</html>
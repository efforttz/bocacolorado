<?php session_start();

  if (!$_SESSION['dni']) {
    header("location:login.php");
  }
  ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/votos.css">
  <title>prueba</title>
</head>

<body>
  <div class="contenedor">
    <div class="cabeza">
      <div class="imagen"><img class="logo" src="img/sofitellogo.png" alt="">
      </div>
      <div class="salir">
        <ul>
          <li><?php echo $_SESSION['dni']; ?></li>
          <li><img class="avatar" src="img/cara.jpg" alt="">
            <ul>
              <li><a href="#">salir</a></li>
              <li><a href="#">salir</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
    <div class="cuerpo">  
        <form class="formulario" action="cod_votos.php" method="POST">


          <input type="hidden" name="nombre" value="<?php echo $_SESSION['dni']; ?>">
          
        
          <table>
            <h2>Sistema de votacion</h2>
            <thead>
              <tr>
                <th>Partido politico</th>
                <th>Simbolo</th>
                <th>votos</th>
              </tr>
            </thead>
            <tbody>
              <?php
              include_once("../cod_conexion.php");
              $consulta_candidatos = "SELECT * FROM candidatos";
              $resultado = mysqli_query($con, $consulta_candidatos);
              while ($rowDataCliente = mysqli_fetch_assoc($resultado)) { ?>
                <tr>
                  <td> <?php echo $rowDataCliente['nombre_candidato']; ?></td>
                  <td><img src="data:image/jpg;base64,<?php echo base64_encode($rowDataCliente['imagen']); ?>" width="80" height="60"></td>
                  <td><input type="radio" name="votos" value="<?php echo $rowDataCliente['partido_politico']; ?>" required></td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
         <center><button class="btn" type="submit" name="enviar">Enviar</button></center>
        </form>
      </div>

  </div>
</body>

</html>


<!-- Button trigger 
      <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">
        ver voto
      </button>

 -------------------------Modal ---------------------------------------
 
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  modal -->

<!-- php 
  

php -->
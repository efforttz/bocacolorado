<?php
session_start();
include_once("../cod_conexion.php");
if (isset($_POST['enviar'])) {
    $nombre = $_POST['nombre'];
    $dni = $_POST['dni'];
    $grado = $_POST['grado'];
    $seccion = $_POST['seccion'];
    $votos = $_POST['votos'];
    $insertar_votos = "INSERT INTO votos(nombre,dni,grado,seccion,votos) VALUES ('$nombre','$dni','$grado','$seccion','$votos')";
    $resultado = mysqli_query($con, $insertar_votos);
    if (!$resultado) {
        die("resultado fallido");
    }
    $_SESSION['mensaje_voto'] = "su voto se ha emetido correctamente";
    $_SESSION['mensaje_type'] = "success";
    header("location:votantes.php");
    exit;
}

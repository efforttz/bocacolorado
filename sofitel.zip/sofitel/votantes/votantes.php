<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/votantes.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <title>prueba</title>
</head>

<body>
    <div class="contenedor">
        <div class="cabeza">
            <div class="imagen"><img class="logo" src="img/sofitellogo.png" alt="">
            </div>
            <div class="salir">
                <ul>
                    <li><a href=""> edwin cayo</a> </li>
                    <li><a href=""> joronimo</a>
                        <ul>
                            <li><a href="">salir</a></li>
                            <li><a href="">salir</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
        <div class="cuerpo">
            <div class="mensaje">
                <p>hola mundo</p>
            </div>
            <div class="mensaje2">
            <p>joder esta situacion</p>
              
            </div>
        </div>    
    </div>
</body>
</html>

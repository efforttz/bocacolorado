<?php
include("cod_conexion.php");
if(isset($_POST['enviar'])){
    $nombre = $_POST['nombre'];
    $dni = $_POST['dni'];
    $grado = $_POST['grado'];
    $seccion = $_POST['seccion'];
    $clave = $_POST['clave'];
    $fechareg = date("y/m/d H:i a");
    $insertar_datos = "INSERT INTO alumnos(nombre, dni, grado, seccion, clave,fecha_reg) VALUES ('$nombre','$dni','$grado','$seccion','$clave','$fechareg')";
    include("verificador/cod_verificar_dni.php");
    $resultado = mysqli_query($con,$insertar_datos);
    if(!$resultado){
        die("resultado fallido");
    }
    header("location: index.php");
}

?>


<?php
include("cod_conexion.php");
   if(isset($_POST['editar'])){
       $idActualizar = $_POST['id'];
       $nombre = $_POST['nombre'];
       $dni = $_POST['dni'];
       $grado = $_POST['grado'];
       $seccion = $_POST['seccion'];
       $clave = $_POST['clave'];
       $editar_datos = "UPDATE alumnos SET nombre='$nombre', dni='$dni', grado='$grado', seccion='$seccion', clave ='$clave' WHERE id=$idActualizar";
       $resultado = mysqli_query($con, $editar_datos);
       header("location: index.php");
   } 
   $_SESSION['nn']=$nombre;
?>








<!--ventana modal editar--->
<div class="modal fade" id="modal_editar<?php echo $rowDataCliente['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header btn btn-success d-flex justify-content-center">
        <h4 class="modal-title">
          Actualizar Información
        </h4>
      </div>
      <form action="cod_editar.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $rowDataCliente['id']; ?>">

        <div class="modal-body" id="cont_modal">

          <div class="mb-1 row">
            <label for="nombre" class="col-sm-3 control-label text-md-right"><strong>Nombre:</strong></label>
            <div class="col-sm-9">
            <input type="text" name="nombre" class="form-control" value="<?php echo $rowDataCliente['nombre']; ?>">
            </div>
          </div>

          <div class="mb-1 row">
            <label for="" class="col-sm-3 control-label text-md-right"><strong>Dni:</strong></label>
            <div class="col-sm-9">
            <input type="number" name="dni" class="form-control" value="<?php echo $rowDataCliente['dni']; ?>">
            </div>
          </div>  

          <div class="mb-1 row">
            <label for="" class="col-sm-3 control-label text-md-right"><strong>Grado:</strong></label>
            <div class="col-sm-9">
            <input type="text" name="grado" class="form-control" value="<?php echo $rowDataCliente['grado']; ?>">
            </div>
          </div>

            <div class="mb-1 row">
              <label for="" class="col-sm-3 control-label text-md-right"><strong>Seccion:</strong></label>
              <div class="col-sm-9">
                <input type="text" name="seccion" class="form-control" value="<?php echo $rowDataCliente['seccion']; ?>">
              </div>           
            </div>

          <div class="mb-1 row">
            <label for="" class="col-sm-3 control-label text-md-right"><strong>Contraseña:</strong></label>
            <div class="col-sm-9">
            <input type="password" name="clave" class="form-control" value="<?php echo $rowDataCliente['clave']; ?>">
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cerrar</button>
          <button type="submit" name="editar" class="btn btn-danger">Guardar</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!---fin ventana Update --->


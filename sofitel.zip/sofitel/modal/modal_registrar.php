   <!-- Modal registrar-->
   <div class="modal fade" id="modal_registrar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
       <div class="modal-dialog">
           <div class="modal-content">
               <div class="modal-header btn btn-success d-flex justify-content-center">
                   <h4 class="modal-title ">¡Registrar Datos!</h4>

               </div>
               <div class="modal-body">
                   <form action="cod_registrar.php" class="" method="POST">


                       <div class="mb-1 row">
                           <label for="nombre" class="col-sm-3 control-label text-md-right"><strong>Nombre:</strong></label>
                           <div class="col-sm-9">
                               <input type="text" name="nombre" class="form-control" required="true" autofocus>
                           </div>
                       </div>

                       <div class="mb-1 row">
                           <label for="nombre" class="col-sm-3 control-label text-md-right"><strong>Dni:</strong></label>
                           <div class="col-sm-9">
                               <input type="number" name="dni" class="form-control" required="true">
                           </div>
                       </div>

                       <div class="mb-1 row">
                           <label for="nombre" class="col-sm-3 control-label text-md-right"><strong>Grado:</strong></label>
                           <div class="col-sm-9">
                               <input type="text" name="grado" class="form-control" required="true">
                           </div>
                       </div>

                       <div class="mb-1 row">
                           <label for="nombre" class="col-sm-3 control-label text-md-right"><strong>Seccion:</strong></label>
                           <div class="col-sm-9">
                               <input type="text" name="seccion" class="form-control" required="true">
                           </div>
                       </div>

                       <div class="mb-1 row">
                           <label for="nombre" class="col-sm-3 control-label text-md-right"><strong>Contraseña:</strong></label>
                           <div class="col-sm-9">
                               <input type="password" name="clave" class="form-control" required="true">
                           </div>
                       </div>

                       <div class="modal-footer">
                           <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cerrar</button>
                           <button type="submit" class="btn btn-danger" name="enviar">guardar</button>
                       </div>
                   </form>
               </div>
           </div>
       </div>
   </div>
   <!-- Modal registrar-->

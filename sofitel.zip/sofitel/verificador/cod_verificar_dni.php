<?php 
$consultarDni = "SELECT * FROM alumnos WHERE dni = '$dni'";
$resultado = mysqli_query($con,$consultarDni);
if(mysqli_num_rows($resultado) > 0){
    echo '
    <script>
    alert("este DNI ya existe");
    window.location = "index.php";
    </script>
    ';
    exit();
} 
?>


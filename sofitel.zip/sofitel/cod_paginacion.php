<?php
include("cod_conexion.php");
$consultaPag = "SELECT * FROM alumnos";
$resultado = mysqli_query($con,$consultaPag);
$totalrecorido = mysqli_num_rows($resultado);
$totalpaginas = ceil($totalrecorido/$numero_por_pag);
if($page>1)
{
    echo "<a href='index.php?page=".($page-1)."' class='btn btn-outline-primary'>Anterior</a>";
}
for($i=1;$i<=$totalpaginas;$i++)
{
    echo "<a href='index.php?page=".$i."' class='btn btn-outline-primary'>$i</a>";
}
if($i>$page)
{
    echo "<a href='index.php?page=".($page+1)."' class='btn btn-outline-primary'>Siguiente</a>";
}


?>
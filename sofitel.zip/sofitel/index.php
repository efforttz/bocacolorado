
<!--  nuestro header -->
<?php include("includes/header.php"); ?>
    <div class="container">
        <div class="p-2 col-12">
              <!--  Modal Registrar-->
              <?php include("modal/modal_registrar.php"); ?>
                <!-- buton Modal Registrar-->
                <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#modal_registrar"><i class="fas fa-user-plus "></i> Nuevo Usuario</button>
                
                <a href="cod_reportes.php" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                <i class="fas fa-download fa-sm"></i> Reportes Pdf</a>
        </div>
        <div class="table-responsive">
            <table id="alumnos" class="table table-striped table-bordered">
                <thead>
                    <?php include("cod_conexion.php");
                    $datos_alumno = "SELECT * FROM alumnos ORDER BY ID DESC";
                    $resultado = mysqli_query($con, $datos_alumno);
                    ?>
                        <tr>
                        <th>ID</th>
                        <th>NOMBRE COMPLETO</th>
                        <th>DNI</th>
                        <th>GRADO</th>
                        <th>SECCION</th>
                        <th>CLAVE</th>
                        <th>ACCIONES</th>    
                    </tr>
                </thead>
                <?php
               while ($rowDataCliente = mysqli_fetch_assoc($resultado)) { ?>
                <tr>
                    <td><?php echo $rowDataCliente['id']; ?></td>
                    <td><?php echo $rowDataCliente['nombre']; ?></td>
                    <td><?php echo $rowDataCliente['dni']; ?></td>
                    <td><?php echo $rowDataCliente['grado']; ?></td>
                    <td><?php echo $rowDataCliente['seccion']; ?></td>
                    <td><?php echo $rowDataCliente['clave']; ?></td>
             
                    <td>
                        <button type="button" class="btn btn-sm btn-warning"data-bs-toggle="modal" data-bs-target="#modal_editar<?php echo $rowDataCliente['id']; ?>">
                        Editar
                        </button>                          
                        <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#modal_eliminar<?php echo $rowDataCliente['id']; ?>">
                        Eliminar
                        </button>
                    </td>
                </tr>
                 <!--  Modal eliminar-->
                 <?php include("modal/modal_eliminar.php"); ?>
                            <!--  Modal editar-->
                            <?php include("modal/modal_editar.php"); ?>
                <?php } ?>
            </table>
        </div>
    </div>

<!--  nuestro footer-->
<?php include("includes/footer.php"); ?>


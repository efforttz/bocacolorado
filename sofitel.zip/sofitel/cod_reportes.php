<?php
include("pdf/fpdf.php");


class PDF extends FPDF
{
// Cabecera de página
function Header()
{
    // Logo
    $this->Image('img/edwin.png',165,2,30);
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Movernos a la derecha
    $this->Cell(80);
    // Título
    $this->Cell(30,15,'REPORTE DEL CUADRO ALUMNOS',0,0,'C');
    // Salto de línea
    $this->Ln(20);


    $this-> cell(70,10,'NOMBRE',1,0,"C",0);
    $this-> cell(30,10,'DNI',1,0,"C",0);
    $this-> cell(30,10,'GRADO',1,0,"C",0);
    $this-> cell(60,10,'SECCION',1,1,"C",0);
}

// Pie de página
function Footer()
{
    // Posición: a 1,5 cm del final
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Número de página
    $this->Cell(0,10,'Sofitel-Peru-Pag'.$this->PageNo().'/{nb}',0,0,'R');
}
}


include_once("cod_conexion.php");
$consultaPaginacion = "SELECT * FROM alumnos";
$resultado = mysqli_query($con, $consultaPaginacion);

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','',12);




while ($rowDataCliente = $resultado->fetch_assoc()){
    $pdf-> cell(70,10,$rowDataCliente['nombre'],1,0,"C",0);
    $pdf-> cell(30,10,$rowDataCliente['dni'],1,0,"C",0);
    $pdf-> cell(30,10,$rowDataCliente['grado'],1,0,"C",0);
    $pdf-> cell(60,10,$rowDataCliente['seccion'],1,1,"C",0);
}

//$pdf -> cell(190,10,"hola mundo cruel puno peru",0,0,"C");
$pdf->Output();

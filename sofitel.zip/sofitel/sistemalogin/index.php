

<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login y Register - MagtimusPro</title>

    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <link rel="stylesheet" href="assets/css/estilos.css">

    <script src="https://kit.fontawesome.com/a265c79f71.js" crossorigin="anonymous"></script>
</head>

<body>

    <main>

        <div class="contenedor__todo">
            <div class="caja__trasera">
                <div class="caja__trasera-login">
                    <h3>¿Ya tienes una cuenta?</h3>
                    <p>Inicia sesión para entrar en la página</p>
                    <button id="btn__iniciar-sesion">Iniciar Sesión</button>
                </div>
                <div class="caja__trasera-register">
                    <h3>¿Aún no tienes una cuenta?</h3>
                    <p>Regístrate para que puedas iniciar sesión</p>
                    <button id="btn__registrarse">Regístrarse</button>
                </div>
            </div>
            <!--Formulario de Login y registro-->

            <div class="contenedor__login-register">
                <!--Login-->
                <form action="iniciosesion/codLogin.php" method="POST" class="formulario__login">

                <?php
                    if (isset($_SESSION['mensaje'])) { ?>
                        <div class="alert alert-<?= $_SESSION['mensaje_type']; ?> alert-dismissible fade show" role="alert">
                            <?= $_SESSION['mensaje']; ?>
                        </div>
                    <?php  session_destroy();                        
                    } ?>

                    <h2>Iniciar Sesión</h2>
                    <input type="hidden" name="nombre">
                    <input type="text" name="correo" placeholder="Correo Electronico" required="true">
                    <input type="password" name="clave" placeholder="Contraseña" required="true">
                    <button type="submit" name="iniciar">Iniciar</button>
                </form>
                <!--Register-->
                <form action="registrodatos/Codregistro.php" method="POST" class="formulario__register">
                    <?php
                    if (isset($_SESSION['message'])) { ?>
                        <div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
                            <?= $_SESSION['message']; ?>
                        </div>
                    <?php session_destroy();
                    } ?>
                    <h2>Regístrarse</h2>
                    <input type="text" name="nombre" placeholder="Nombre Completo" required="true">
                    <input type="number" maxlength="8" oninput="if(this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength)" name="dni" placeholder="Dni" required="true">
                    <input type="number" maxlength="9" oninput="if(this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength)" name="celular" placeholder="Nº celular" required="true">
                    <input type="email" name="correo" placeholder="correo" required="true">
                    <input type="password" name="clave" placeholder="contraseña" required="true">
                    <button type="submit" name="registrar">Registrar</button>
                </form>
            </div>
        </div>

    </main>

    <script src="assets/js/script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous"></script>
</body>

</html>
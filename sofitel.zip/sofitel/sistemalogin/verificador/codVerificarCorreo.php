<?php 
$consultar_correo = "SELECT * FROM administradores WHERE correo = '$correo'";
$resultado = mysqli_query($con,$consultar_correo);
if(mysqli_num_rows($resultado) > 0){
    echo '
    <script>
    alert("este correo ya existe");
    window.location = "../index.php";
    </script>
    ';
    exit();
} 
?>


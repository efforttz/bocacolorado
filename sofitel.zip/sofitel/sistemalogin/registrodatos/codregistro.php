<?php
session_start();
require '../../cod_conexion.php';
if (isset($_POST['registrar'])) {
    $nombre = $_POST['nombre'];
    $dni = $_POST['dni'];
    $celular = $_POST['celular'];
    $correo = $_POST['correo'];
    $clave = $_POST['clave'];
    //encriptamiendo de contraseña
    $clave = hash('md5', $clave);
    $fechareg = date("y/m/d H:i a");
    $registro_datos = "INSERT INTO administradores(nombre, dni, celular, correo, clave,fecha_reg) VALUES ('$nombre','$dni','$celular','$correo','$clave','$fechareg')";
    include("../verificador/codVerificarCorreo.php");
    $resultado = mysqli_query($con, $registro_datos);
    if (!$resultado) {
        die("resultado fallido");
    }
    //inicio de sesion para mostrar mensaje de correcto o incorrecto
    $_SESSION['message'] = 'registrado correctamente';
    $_SESSION['message_type'] = 'primary';
    header("location: ../index.php");
    exit;
}
?>

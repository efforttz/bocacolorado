<?php include("../../cod_conexion.php"); ?>
<?php include("../../includes/header.php");  ?>
<?php session_start(); ?>
<div class="container p-4">
	<div class="row justify-content-center">
		<div class="col-md-5 text-center">
			<?php if (isset($_SESSION['message'])) { ?>
				<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
					<?= $_SESSION['message']; ?>
					<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
				</div>
			<?php session_unset();
			} ?>
			<div class="card card-body">
				<form action="Codregistro.php" method="POST">
					<h1>¡Registrate!</h1>
					<input type="text" class="form-control mb-2 mr-sm-2" name="nombre" placeholder="Nombre Completo">
					<input type="number" class="form-control mb-2 mr-sm-2" name="dni" placeholder="Dni">
					<input type="number" class="form-control mb-2 mr-sm-2" name="celular" placeholder="Nº celular">
					<input type="email" class="form-control mb-2 mr-sm-2" name="correo" placeholder="correo">
					<input type="password" class="form-control mb-2 mr-sm-2" name="clave" placeholder="contraseña">
					<button type="submit" class="btn btn-primary form-control" name="registrar">Registrar</button>
				</form>
			</div>
		</div>
	</div>
</div>
<?php include("../../includes/footer.php"); ?>
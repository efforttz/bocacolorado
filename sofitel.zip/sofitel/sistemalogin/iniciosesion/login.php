        
         <?php session_start(); ?>
         <?php include("../../includes/header.php");  ?>
         <div class="container p-4">
             <div class="row justify-content-center">
                 <div class="col-md-5 text-center">


                     <?php if (isset($_SESSION['message'])) { ?>
                         <div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
                             <?= $_SESSION['message']; ?>
                             <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                         </div>
                     <?php session_unset();
                        } ?>


                     <div class="card card-body">
                         <form action="Codlogin.php" method="POST">
                             <h1>¡Inicia Sesion!</h1>
                             <input type="email" class="form-control mb-2 mr-sm-2" name="correo" placeholder="admin@sofitel.com" autofocus>
                             <input type="password" class="form-control mb-2 mr-sm-2" name="clave" placeholder="contraseña">
                             <input type="submit" class="btn btn-primary form-control" name="iniciar" value="Iniciar Sesion">
                         </form>
                     </div>
                 </div>
             </div>
         </div>
         <?php include("../../includes/footer.php"); ?>
<?php
session_start();
require '../../cod_conexion.php';
if (isset($_POST['iniciar'])) {
    $correo = $_POST['correo'];
    $clave = $_POST['clave'];
    //encriptamiendo de contraseña
    $clave = hash('md5', $clave);
    $seleccionar_datos = "SELECT * FROM administradores WHERE correo = '$correo' and clave = '$clave' ";
    $resultado = mysqli_query($con, $seleccionar_datos);
    $array = mysqli_num_rows($resultado);
    if ($array > 0) {
        //iniar sesion con correo
        $_SESSION['usuario'] = $correo;
        header("location: ../../index.php");
        exit;
    } else {
        //iniar sesion para mostar mensaje de correcto o incorrecto
        $_SESSION['mensaje'] = "usuario o clave  incorrecto";
        $_SESSION['mensaje_type'] = "danger";
        header("location: ../index.php");
        exit;
    }
}
